package net.codewyrm.dwdsb.util;

import net.codewyrm.dwdsb.Dwdsb;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1914;
import net.minecraft.class_9306;

import static net.codewyrm.dwdsb.Dwdsb.MOD_ID;
import static net.codewyrm.dwdsb.registry.ItemRegistry.UNREFINED_DISC_CORE;
import static net.minecraft.class_1802.field_8687;

public class TradeModifier {
    public static void ModifyTrades() {
        TradeOfferHelper.registerWanderingTraderOffers(1,
                factories -> {
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(field_8687,7),
                            new class_1799(UNREFINED_DISC_CORE, 1),
                            1, 10, 0.075f));
                });
        Dwdsb.LOGGER.info("[4/5] Trages modified for DWDSB successfully!");
    }
}
