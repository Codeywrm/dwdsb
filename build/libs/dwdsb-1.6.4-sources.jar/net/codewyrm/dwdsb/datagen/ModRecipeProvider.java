
package net.codewyrm.dwdsb.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8074;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;
import static net.minecraft.class_1802.*;
import static net.minecraft.class_1856.*;

public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 registries, class_8790 exporter) {

        return new class_2446(registries, exporter) {

            private void generateDiscRecipe(class_1792 disc, class_1792 addition) {
                class_8074
                        .method_48535(method_8101(UNREFINED_DISC_CORE), method_8101(field_22021), method_8101(addition), class_7800.field_40638, disc)
                        .method_48536(method_32807(UNREFINED_DISC_CORE), method_10426(UNREFINED_DISC_CORE))
                        .method_48538(field_53721, method_36450(disc) + "_smithing");
            }

            private void generateWhistleRecipe(class_1792 whistle, class_1792 addition) {
                class_8074
                        .method_48535(method_8101(ANCIENT_WHISTLE), method_8101(field_27022), method_8101(addition), class_7800.field_40638, whistle)
                        .method_48536(method_32807(ANCIENT_WHISTLE), method_10426(ANCIENT_WHISTLE))
                        .method_48538(field_53721, method_36450(whistle) + "_smithing");
            }

            @Override
            public void method_10419() {
                generateDiscRecipe(WAVE, field_8662);
                generateDiscRecipe(LOST, field_38746);
                generateDiscRecipe(MIRROR, field_27063);
                generateDiscRecipe(RAIN, field_28659);
                generateDiscRecipe(EMBER, field_22020);

                generateWhistleRecipe(AMETHYST_WHISTLE, field_27063);
                generateWhistleRecipe(GOLD_WHISTLE, field_8695);
                generateWhistleRecipe(DIAMOND_WHISTLE, field_8477);
                generateWhistleRecipe(EMERALD_WHISTLE, field_8687);
            }
        };
    }

    @Override
    public String method_10321() {
        return "";
    }
}