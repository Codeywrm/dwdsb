package net.codewyrm.dwdsb.item;

import java.util.Arrays;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5712;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;

public class WhistleItem extends class_1792 {
    private final class_3414 JINGLE;
    private final Integer COOLDOWN;

    public WhistleItem(class_1793 settings, class_3414 jingle, Integer cooldown) {
        super(settings);
        this.JINGLE = jingle;
        this.COOLDOWN = cooldown;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        world.method_43129(user, user, JINGLE, class_3419.field_15247, 2.0f, 1.0f );
        world.method_32888(class_5712.field_39415, user.method_19538(), class_5712.class_7397.method_43285(user));

        for (class_1792 item : Arrays.asList(
                ANCIENT_WHISTLE,
                AMETHYST_WHISTLE,
                GOLD_WHISTLE,
                DIAMOND_WHISTLE,
                EMERALD_WHISTLE))
        {user.method_7357().method_62835(new class_1799(item), COOLDOWN * 20);}

        return class_1269.field_5812;
    }
}