package net.codewyrm.dwdsb.registry;

import net.codewyrm.dwdsb.util.Util;
import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class TagRegistry {
    public static final class_6862<class_1792> VANILLA_DISCS = createTag("vanilla_discs");
    public static final class_6862<class_1792> MOD_DISCS = createTag("mod_discs");
    public static final class_6862<class_1792> ROOT_ITEMS = createTag("root_items");
    public static final class_6862<class_1792> WHISTLES = createTag("whistles");
    private static class_6862<class_1792> createTag(String name) {
        return class_6862.method_40092(class_7924.field_41197, Util.ofDWDSB(name));
    }
}
