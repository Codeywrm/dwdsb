package net.codewyrm.dwdsb.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_4910;
import net.minecraft.class_4915;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;
import static net.minecraft.class_4943.*;

public class ModModelProvider extends FabricModelProvider {

    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(DISC_CORE, field_22938);

        itemModelGenerator.method_65442(MELODY_POTTERY_SHERD, field_22938);
        itemModelGenerator.method_65442(RECORD_POTTERY_SHERD, field_22938);
        itemModelGenerator.method_65442(SOLO_POTTERY_SHERD, field_22938);

        itemModelGenerator.method_65453(ANCIENT_WHISTLE);
        itemModelGenerator.method_65453(AMETHYST_WHISTLE);
        itemModelGenerator.method_65453(GOLD_WHISTLE);
        itemModelGenerator.method_65453(DIAMOND_WHISTLE);
        itemModelGenerator.method_65453(EMERALD_WHISTLE);

        itemModelGenerator.method_65442(WAVE, field_22938);
        itemModelGenerator.method_65442(LOST, field_22938);
        itemModelGenerator.method_65442(WATCHED, field_22938);
        itemModelGenerator.method_65442(REST, field_22938);

        itemModelGenerator.method_65442(MIRROR, field_22938);
        itemModelGenerator.method_65442(RAIN, field_22938);
        itemModelGenerator.method_65442(ALONE, field_22938);

        itemModelGenerator.method_65442(BEAN, field_22938);
        itemModelGenerator.method_65442(LYRE, field_22938);
        itemModelGenerator.method_65442(EMBER, field_22938);

        itemModelGenerator.method_65442(STAR, field_22938);
        itemModelGenerator.method_65442(RAVE, field_22938);
        itemModelGenerator.method_65442(WALTZ, field_22938);
        itemModelGenerator.method_65442(SUNSET, field_22938);
    }
}
