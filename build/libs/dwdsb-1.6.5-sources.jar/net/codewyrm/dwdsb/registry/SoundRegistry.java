package net.codewyrm.dwdsb.registry;

import static net.codewyrm.dwdsb.Dwdsb.MOD_ID;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class SoundRegistry {

// Registers SoundEvents
    public static final class_3414 WAVE = registerSoundEvent("wave");
    public static final class_3414 LOST = registerSoundEvent("lost");
    public static final class_3414 WATCHED = registerSoundEvent("watched");
    public static final class_3414 REST = registerSoundEvent("rest");

    public static final class_3414 MIRROR = registerSoundEvent("mirror");
    public static final class_3414 RAIN = registerSoundEvent("rain");
    public static final class_3414 ALONE = registerSoundEvent("alone");

    public static final class_3414 BEAN = registerSoundEvent("bean");
    public static final class_3414 LYRE = registerSoundEvent("lyre");
    public static final class_3414 EMBER = registerSoundEvent("ember");

    public static final class_3414 STAR = registerSoundEvent("star");
    public static final class_3414 RAVE = registerSoundEvent("rave");
    public static final class_3414 WALTZ = registerSoundEvent("waltz");
    public static final class_3414 SUNSET = registerSoundEvent("sunset");

    public static final class_3414 ANCIENT_JINGLE = registerSoundEvent("ancient_jingle");
    public static final class_3414 AMETHYST_JINGLE = registerSoundEvent("amethyst_jingle");
    public static final class_3414 GOLD_JINGLE = registerSoundEvent("gold_jingle");
    public static final class_3414 DIAMOND_JINGLE = registerSoundEvent("diamond_jingle");
    public static final class_3414 EMERALD_JINGLE = registerSoundEvent("emerald_jingle");

// Registers Keys
    public static final class_2960 WAVE_SOUND_KEY = class_2960.method_60654("dwdsb:wave");
    public static final class_2960 LOST_SOUND_KEY = class_2960.method_60654("dwdsb:lost");
    public static final class_2960 WATCHED_SOUND_KEY = class_2960.method_60654("dwdsb:watched");
    public static final class_2960 REST_SOUND_KEY = class_2960.method_60654("dwdsb:rest");

    public static final class_2960 MIRROR_SOUND_KEY = class_2960.method_60654("dwdsb:mirror");
    public static final class_2960 RAIN_SOUND_KEY = class_2960.method_60654("dwdsb:rain");
    public static final class_2960 ALONE_SOUND_KEY = class_2960.method_60654("dwdsb:alone");

    public static final class_2960 BEAN_SOUND_KEY = class_2960.method_60654("dwdsb:bean");
    public static final class_2960 LYRE_SOUND_KEY = class_2960.method_60654("dwdsb:lyre");
    public static final class_2960 EMBER_SOUND_KEY = class_2960.method_60654("dwdsb:ember");

    public static final class_2960 STAR_SOUND_KEY = class_2960.method_60654("dwdsb:star");
    public static final class_2960 RAVE_SOUND_KEY = class_2960.method_60654("dwdsb:rave");
    public static final class_2960 WALTZ_SOUND_KEY = class_2960.method_60654("dwdsb:waltz");
    public static final class_2960 SUNSET_SOUND_KEY = class_2960.method_60654("dwdsb:sunset");

    public static final class_2960 ANCIENT_JINGLE_SOUND_KEY = class_2960.method_60654("dwdsb:ancient_jingle");
    public static final class_2960 AMETHYST_JINGLE_SOUND_KEY = class_2960.method_60654("dwdsb:amethyst_jingle");
    public static final class_2960 GOLD_JINGLE_SOUND_KEY = class_2960.method_60654("dwdsb:gold_jingle");
    public static final class_2960 DIAMOND_JINGLE_SOUND_KEY = class_2960.method_60654("dwdsb:diamond_jingle");
    public static final class_2960 EMERALD_JINGLE_SOUND_KEY = class_2960.method_60654("dwdsb:emerald_jingle");


    private static class_3414 registerSoundEvent(String name) {
        class_2960 id = class_2960.method_60655(MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void registersounds() {
    }
}
