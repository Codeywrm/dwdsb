package net.codewyrm.dwdsb.util;

import net.codewyrm.dwdsb.Dwdsb;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import java.util.HashMap;
import java.util.Map;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;
import static net.codewyrm.dwdsb.util.Util.equalsAny;
import static net.codewyrm.dwdsb.util.Util.ofMinecraft;

public class LootTableModifier {
    private static final class_2960 DESERT_PYRAMID_ID = ofMinecraft("chests/desert_pyramid");
    private static final class_2960 END_CITY_ID = ofMinecraft("chests/end_city_treasure");
    private static final class_2960 JUNGLE_TEMPLE_ID = ofMinecraft("chests/jungle_temple");
    private static final class_2960 ABANDONED_MINESHAFT_ID = ofMinecraft("chests/abandoned_mineshaft");
    private static final class_2960 STRONGHOLD_LIBRARY_ID = ofMinecraft("chests/stronghold_library");
    private static final class_2960 IGLOO_ID = ofMinecraft("chests/igloo_chest");
    private static final class_2960 PILLAGER_OUTPOST_ID = ofMinecraft("chests/pillager_outpost");
    private static final class_2960 WOODLAND_MANSION = ofMinecraft("chests/woodland_mansion");
    private static final class_2960 VILLAGE_CARTOGRAPHER = ofMinecraft("chests/village/village_cartographer");
    private static final class_2960 VILLAGE_DESERT_HOUSE = ofMinecraft("chests/village/village_desert_house");
    private static final class_2960 VILLAGE_PLAINS_HOUSE = ofMinecraft("chests/village/village_plains_house");
    private static final class_2960 VILLAGE_SAVANNA_HOUSE = ofMinecraft("chests/village/village_savanna_house");
    private static final class_2960 VILLAGE_SNOWY_HOUSE = ofMinecraft("chests/village/village_snowy_house");
    private static final class_2960 VILLAGE_TAIGA_HOUSE = ofMinecraft("chests/village/village_taiga_house");

    private static final float GUARANTEED = 1f;

    private static void addToLootTable(class_52.class_53 tableBuilder, int max, class_1792 item, float chance) {
        tableBuilder.pool(class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_356(class_219.method_932(chance))
                .method_351(class_77.method_411(item))
                .apply(class_141.method_621(class_5662.method_32462(1, max)).method_515())
                .method_355()
        );
    }
    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            class_2960 id = key.method_29177();
            if (DESERT_PYRAMID_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, LYRE, .15f);
                addToLootTable(tableBuilder, 2, UNREFINED_DISC_CORE, .1f);
            }
            if (END_CITY_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, REST, .1f);
                addToLootTable(tableBuilder, 3, UNREFINED_DISC_CORE, .15f);
            }
            if (JUNGLE_TEMPLE_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, BEAN, .3f);
                addToLootTable(tableBuilder, 2, UNREFINED_DISC_CORE, .1f);
            }
            if (ABANDONED_MINESHAFT_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, ALONE, .2f);
                addToLootTable(tableBuilder, 1, UNREFINED_DISC_CORE, .1f);
            }
            if (STRONGHOLD_LIBRARY_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, WATCHED, GUARANTEED);
            }
            if (IGLOO_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, STAR, GUARANTEED);
            }
            if (PILLAGER_OUTPOST_ID.equals(id)) {
                addToLootTable(tableBuilder, 1, RAVE, .5f);
            }
            if (WOODLAND_MANSION.equals(id)) {
                addToLootTable(tableBuilder, 1, WALTZ, .3f);
            }
            if (VILLAGE_CARTOGRAPHER.equals(id)) {
                addToLootTable(tableBuilder, 1, SUNSET, .5f);
            }
            if (equalsAny(id,
                    VILLAGE_DESERT_HOUSE, VILLAGE_PLAINS_HOUSE, VILLAGE_SAVANNA_HOUSE,
                    VILLAGE_SNOWY_HOUSE, VILLAGE_TAIGA_HOUSE
            )) {
                addToLootTable(tableBuilder, 1, SUNSET, .1f);
            }
// Adds items to Sus blocks.
            if (class_39.field_44648.equals(key)) {
                Map<class_1792, Integer> itemWeights = new HashMap<>();
                itemWeights.put(UNREFINED_DISC_CORE, 1);
                itemWeights.put(ANCIENT_WHISTLE, 2);
                itemWeights.put(MELODY_POTTERY_SHERD, 2);
                itemWeights.forEach((item, weight) ->
                        tableBuilder.modifyPools((poolBuilder) ->
                                poolBuilder.method_351(class_77.method_411(item).method_437(weight))
                        )
                );
            }
            if (class_39.field_43357.equals(key)) {
                Map<class_1792, Integer> itemWeights = new HashMap<>();
                itemWeights.put(RECORD_POTTERY_SHERD, 1);
                itemWeights.forEach((item, weight) ->
                        tableBuilder.modifyPools((poolBuilder) ->
                                poolBuilder.method_351(class_77.method_411(item).method_437(weight))
                        )
                );
            }
            if (class_39.field_43356.equals(key)) {
                Map<class_1792, Integer> itemWeights = new HashMap<>();
                itemWeights.put(SOLO_POTTERY_SHERD, 1);
                itemWeights.forEach((item, weight) ->
                        tableBuilder.modifyPools((poolBuilder) ->
                                poolBuilder.method_351(class_77.method_411(item).method_437(weight))
                        )
                );
            }
            if (class_39.field_44748.equals(key)) {
                tableBuilder.pool(class_55.method_347()
                        .method_35509(class_44.method_32448(1))
                        .method_356(class_219.method_932(.001f))
                        .method_351(class_77.method_411(UNREFINED_DISC_CORE))
                        .method_355()
                );
            }
        });
        Dwdsb.LOGGER.info("[3/5] Loot tables modified for DWDSB successfully!");
    }

}
