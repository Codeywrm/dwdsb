package net.codewyrm.dwdsb.item;

import static net.codewyrm.dwdsb.util.Util.ofDWDSB;

import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9766;

public class ModPotterySherd {
    public static final class_5321<class_9766> MELODY_POTTERY_PATTERN =  of("melody");
    public static final class_5321<class_9766> RECORD_POTTERY_PATTERN =  of("record");
    public static final class_5321<class_9766> SOLO_POTTERY_PATTERN =  of("solo");


    public static void register(class_2378<class_9766> registry, class_5321<class_9766> resourceKey, String string) {
        class_2378.method_39197(registry, resourceKey, new class_9766(ofDWDSB(string)));
    }

    private static class_5321<class_9766> of(String string) {
        return class_5321.method_29179(class_7924.field_42941, ofDWDSB(string));
    }
}
