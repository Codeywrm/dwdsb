package net.codewyrm.dwdsb.datagen;

import net.codewyrm.dwdsb.registry.TagRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;
import static net.codewyrm.dwdsb.registry.TagRegistry.*;

public class ModTagProvider extends FabricTagProvider.ItemTagProvider {

    public ModTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        method_10512(TagRegistry.VANILLA_DISCS)
                .addOptionalTag(class_3489.field_23969)
                .add(class_1802.field_35358)
                .add(class_1802.field_38973)
                .add(class_1802.field_23984)
                .add(class_1802.field_44705)
                .add(class_1802.field_51628)
                .add(class_1802.field_51629)
                .add(class_1802.field_51630);

        method_10512(MOD_DISCS)
                .add(WAVE).add(LOST).add(WATCHED).add(REST)
                .add(MIRROR).add(RAIN).add(ALONE)
                .add(BEAN).add(LYRE).add(EMBER)
                .add(STAR).add(RAVE).add(WALTZ).add(SUNSET);

        method_10512(WHISTLES)
                .add(ANCIENT_WHISTLE)
                .add(AMETHYST_WHISTLE)
                .add(GOLD_WHISTLE)
                .add(DIAMOND_WHISTLE)
                .add(EMERALD_WHISTLE);

        method_10512(ROOT_ITEMS)
                .addOptionalTag(VANILLA_DISCS)
                .addOptionalTag(MOD_DISCS)
                .addOptionalTag(WHISTLES)
                .add(class_1802.field_8643)
                .add(class_1802.field_8565)
                .add(class_1802.field_39057)
                .add(class_1802.field_16315)
                .add(DISC_CORE)
                .add(MELODY_POTTERY_SHERD)
                .add(RECORD_POTTERY_SHERD)
                .add(SOLO_POTTERY_SHERD);

        method_10512(class_3489.field_42610)
                .add(MELODY_POTTERY_SHERD)
                .add(RECORD_POTTERY_SHERD)
                .add(SOLO_POTTERY_SHERD);
    }
}
