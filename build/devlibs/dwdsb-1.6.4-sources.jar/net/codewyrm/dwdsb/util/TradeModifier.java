package net.codewyrm.dwdsb.util;

import net.codewyrm.dwdsb.Dwdsb;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradedItem;

import static net.codewyrm.dwdsb.Dwdsb.MOD_ID;
import static net.codewyrm.dwdsb.registry.ItemRegistry.UNREFINED_DISC_CORE;
import static net.minecraft.item.Items.EMERALD;

public class TradeModifier {
    public static void ModifyTrades() {
        TradeOfferHelper.registerWanderingTraderOffers(1,
                factories -> {
                    factories.add((entity, random) -> new TradeOffer(
                            new TradedItem(EMERALD,7),
                            new ItemStack(UNREFINED_DISC_CORE, 1),
                            1, 10, 0.075f));
                });
        Dwdsb.LOGGER.info("[4/5] Trages modified for DWDSB successfully!");
    }
}
