package net.codewyrm.dwdsb.item;

import java.util.Arrays;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5712;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;

public class WhistleItem extends class_1792 {
    private final class_3414 JINGLE;
    private final Integer COOLDOWN;


    public WhistleItem(class_1793 settings, class_3414 jingle, Integer cooldown) {
        super(settings);
        this.JINGLE = jingle;
        this.COOLDOWN = cooldown;
    }

    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        world.method_43129(user, user, JINGLE, class_3419.field_15247, 2.0f, 1.0f );
        world.method_32888(class_5712.field_39415, user.method_19538(), class_5712.class_7397.method_43285(user));

        Random random = new Random();
        int NOTE_COUNT = random.nextInt(4);
        for (double i = 0; i < NOTE_COUNT + 4; i++) {
            world.method_8406(class_2398.field_11224,
                    user.method_23317() + (Math.random() - 0.5) * 2,
                    user.method_23318() + (Math.random() - 0.5) * 2 + 1,
                    user.method_23321() + (Math.random() - 0.5) * 2,
                    i / 10, 0, 0);
        }

        for (class_1792 item : Arrays.asList(
                ANCIENT_WHISTLE,
                AMETHYST_WHISTLE,
                GOLD_WHISTLE,
                DIAMOND_WHISTLE,
                EMERALD_WHISTLE
                ))
            user.method_7357().method_62835(new class_1799(item), COOLDOWN * 20);
        return class_1269.field_5812;
    }
}