package net.codewyrm.dwdsb.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

import java.util.Arrays;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;

public class WhistleItem extends Item {
    private final SoundEvent JINGLE;
    private final Integer COOLDOWN;

    public WhistleItem(Settings settings, SoundEvent jingle, Integer cooldown) {
        super(settings);
        this.JINGLE = jingle;
        this.COOLDOWN = cooldown;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        world.playSoundFromEntity(user, user, JINGLE, SoundCategory.RECORDS, 2.0f, 1.0f );
        world.emitGameEvent(GameEvent.INSTRUMENT_PLAY, user.getPos(), GameEvent.Emitter.of(user));

        for (Item item : Arrays.asList(
                ANCIENT_WHISTLE,
                AMETHYST_WHISTLE,
                GOLD_WHISTLE,
                DIAMOND_WHISTLE,
                EMERALD_WHISTLE))
        {user.getItemCooldownManager().set(new ItemStack(item), COOLDOWN * 20);}

        return ActionResult.SUCCESS;
    }
}