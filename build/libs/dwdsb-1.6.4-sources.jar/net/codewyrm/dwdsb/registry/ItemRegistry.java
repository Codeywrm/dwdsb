package net.codewyrm.dwdsb.registry;

import net.codewyrm.dwdsb.Dwdsb;
import net.codewyrm.dwdsb.item.WhistleItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7924;
import java.util.function.Function;

import static net.codewyrm.dwdsb.registry.SoundRegistry.*;
import static net.minecraft.class_1802.method_51348;

public class ItemRegistry {
    public static final class_1792 UNREFINED_DISC_CORE = registerItem("unrefined_disc_core", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8907));

// SHERDS
    public static final class_1792 MELODY_POTTERY_SHERD = registerItem("melody_pottery_sherd", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8907));
    public static final class_1792 RECORD_POTTERY_SHERD = registerItem("record_pottery_sherd", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8907));
    public static final class_1792 SOLO_POTTERY_SHERD = registerItem("solo_pottery_sherd", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8907));

// WHISTLE
public static final class_1792 ANCIENT_WHISTLE = registerItem("ancient_whistle",
        (settings) -> new WhistleItem(settings, ANCIENT_JINGLE, 15),
        new class_1792.class_1793()
                .method_7889(1)
                .method_7894(class_1814.field_8907));
    public static final class_1792 AMETHYST_WHISTLE = registerItem("amethyst_whistle",
            (settings) -> new WhistleItem(settings, AMETHYST_JINGLE, 17),
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_7894(class_1814.field_8907));
    public static final class_1792 GOLD_WHISTLE = registerItem("gold_whistle",
            (settings) -> new WhistleItem(settings, GOLD_JINGLE, 21),
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_7894(class_1814.field_8907));
    public static final class_1792 DIAMOND_WHISTLE = registerItem("diamond_whistle",
            (settings) -> new WhistleItem(settings, DIAMOND_JINGLE, 17),
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_7894(class_1814.field_8907));
    public static final class_1792 EMERALD_WHISTLE = registerItem("emerald_whistle",
            (settings) -> new WhistleItem(settings, EMERALD_JINGLE, 16),
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_7894(class_1814.field_8907));

// DISCS WHERE DISCS SHOULDN'T BE
    public static final class_1792 WAVE = registerItem("wave",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, WAVE_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 LOST = registerItem("lost",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, LOST_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8904));
    public static final class_1792 WATCHED = registerItem("watched",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, WATCHED_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8903));
    public static final class_1792 REST = registerItem("rest",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, REST_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8903));

//GOING DEEPER
    public static final class_1792 MIRROR = registerItem("mirror",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, MIRROR_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 RAIN = registerItem("rain",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, RAIN_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 ALONE = registerItem("alone",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, ALONE_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));

// LOST TO TIME
    public static final class_1792 BEAN = registerItem("bean",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, BEAN_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 LYRE = registerItem("lyre",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, LYRE_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 EMBER = registerItem("ember",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, EMBER_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8903));

// JOURNEY'S END
    public static final class_1792 STAR = registerItem("star",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, STAR_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 RAVE = registerItem("rave",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, RAVE_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));
    public static final class_1792 WALTZ = registerItem("waltz",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, WALTZ_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8903));
    public static final class_1792 SUNSET = registerItem("sunset",class_1792::new, new class_1792.class_1793()
            .method_60745(class_5321.method_29179(class_7924.field_52176, SUNSET_SOUND_KEY))
            .method_7889(1)
            .method_7894(class_1814.field_8907));

    public static class_1792 registerItem(String path, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        final class_5321<class_1792> registryKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655("dwdsb", path));
        return method_51348(registryKey, factory, settings);
    }

    public static void registerItems() {

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> {
            content.addAfter(class_1802.field_23984,
                    WAVE, LOST, WATCHED, REST,
                    MIRROR, RAIN, ALONE,
                    BEAN, LYRE, EMBER,
                    STAR, RAVE, WALTZ, SUNSET,
                    ANCIENT_WHISTLE, AMETHYST_WHISTLE, GOLD_WHISTLE,
                    DIAMOND_WHISTLE, EMERALD_WHISTLE);
            }
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(content -> {
            content.addAfter(class_1802.field_38974, UNREFINED_DISC_CORE);
            }
        );
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(content -> {
            content.addAfter(class_1802.field_43220,
                    MELODY_POTTERY_SHERD, RECORD_POTTERY_SHERD, SOLO_POTTERY_SHERD);
            }
        );

        Dwdsb.LOGGER.info("[1/5] Registered items for DWDSB successfully!");
    }
}