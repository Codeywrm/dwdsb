package net.codewyrm.dwdsb.registry;

import net.codewyrm.dwdsb.util.Util;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import java.util.Arrays;

import static net.codewyrm.dwdsb.registry.ItemRegistry.*;

public class ItemGroupRegistry {
    public static final class_1761 DWDSB_ITEMS_GROUP = class_2378.method_10230(class_7923.field_44687,
            Util.ofDWDSB("dwdsb_items"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(DISC_CORE))
                    .method_47321(class_2561.method_43471("itemgroup.dwdsb.dwdsb_items"))
                    .method_47317((displayContext, entries) ->
                    {
                        for (class_1792 item : Arrays.asList(
                                WAVE, LOST, WATCHED, REST,
                                MIRROR, RAIN, ALONE,
                                BEAN, LYRE, EMBER,
                                STAR, RAVE, WALTZ, SUNSET,
                                DISC_CORE,
                                ANCIENT_WHISTLE,
                                AMETHYST_WHISTLE,
                                GOLD_WHISTLE,
                                DIAMOND_WHISTLE,
                                EMERALD_WHISTLE,
                                MELODY_POTTERY_SHERD,
                                RECORD_POTTERY_SHERD,
                                SOLO_POTTERY_SHERD
                        )) {
                            entries.method_45421(item);
                        }
                    })
                    .method_47324());
    public static void registerItemGroups() {
    }
}
