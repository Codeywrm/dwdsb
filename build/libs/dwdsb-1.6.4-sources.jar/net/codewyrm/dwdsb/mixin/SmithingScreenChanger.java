package net.codewyrm.dwdsb.mixin;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4862;
import net.minecraft.class_4894;
import net.minecraft.class_4895;

import static net.minecraft.class_1802.field_8477;

@Mixin(class_4895.class)
public abstract class SmithingScreenChanger extends class_4894<class_4862> {

	@Unique
	private static final class_2960 EMPTY_SLOT_UNREFINED_DISC_CORE = class_2960.method_60656("item/diamond");
	@Unique
	private static final class_2960 EMPTY_SLOT_ANCIENT_WHISTLE =  class_2960.method_60654("gui/sprites/container/slot/boots");

	@Shadow @Final private static class_2960 EMPTY_SLOT_SMITHING_TEMPLATE_ARMOR_TRIM_TEXTURE;
	@Shadow @Final private static class_2960 EMPTY_SLOT_SMITHING_TEMPLATE_NETHERITE_UPGRADE_TEXTURE;
	@Shadow @Final private static final List<class_2960> EMPTY_SLOT_TEXTURES = List.of(
			EMPTY_SLOT_UNREFINED_DISC_CORE,
			EMPTY_SLOT_ANCIENT_WHISTLE
	);

	public SmithingScreenChanger(class_4862 handler, class_1661 playerInventory, class_2561 title, class_2960 texture) {
		super(handler, playerInventory, title, texture);
	}
}