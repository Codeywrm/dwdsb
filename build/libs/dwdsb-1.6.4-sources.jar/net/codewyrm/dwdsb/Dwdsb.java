package net.codewyrm.dwdsb;

import net.codewyrm.dwdsb.registry.ItemRegistry;
import net.codewyrm.dwdsb.registry.SoundRegistry;
import net.codewyrm.dwdsb.util.LootTableModifier;
import net.codewyrm.dwdsb.util.TradeModifier;
import net.fabricmc.api.ModInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Dwdsb implements ModInitializer {
	public static final String MOD_ID = "dwdsb";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ItemRegistry.registerItems();
		SoundRegistry.registersounds();
		LootTableModifier.modifyLootTables();
		TradeModifier.ModifyTrades();

		LOGGER.info("[5/5] All content loaded. Ready for some killer beats?");
	}
}