package net.codewyrm.dwdsb.mixin;

import net.codewyrm.dwdsb.item.ModPotterySherd;
import net.codewyrm.dwdsb.registry.ItemRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_8173;
import net.minecraft.class_9766;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8173.class)
public class DecoratedPotPatternsChanger {

	@Inject(method = "fromSherd", at = @At("HEAD"), cancellable = true)
	private static void fromSherd(class_1792 item, CallbackInfoReturnable<class_5321<class_9766>> cir) {
		if (item == ItemRegistry.MELODY_POTTERY_SHERD) {
			cir.setReturnValue(ModPotterySherd.MELODY_POTTERY_PATTERN);
		}
		if (item == ItemRegistry.RECORD_POTTERY_SHERD) {
			cir.setReturnValue(ModPotterySherd.RECORD_POTTERY_PATTERN);
		}
		if (item == ItemRegistry.SOLO_POTTERY_SHERD) {
			cir.setReturnValue(ModPotterySherd.SOLO_POTTERY_PATTERN);
		}
	}

	@Inject(method = "registerAndGetDefault", at = @At("TAIL"))
	private static void registerAndGetDefault(class_2378<class_9766> registry, CallbackInfoReturnable<String> cir) {
		ModPotterySherd.register(registry, ModPotterySherd.MELODY_POTTERY_PATTERN, "melody_pottery_pattern");
		ModPotterySherd.register(registry, ModPotterySherd.RECORD_POTTERY_PATTERN, "record_pottery_pattern");
		ModPotterySherd.register(registry, ModPotterySherd.SOLO_POTTERY_PATTERN, "solo_pottery_pattern");
	}
}
