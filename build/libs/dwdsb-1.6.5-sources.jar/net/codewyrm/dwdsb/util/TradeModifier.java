package net.codewyrm.dwdsb.util;

import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1914;
import net.minecraft.class_9306;

import static net.codewyrm.dwdsb.registry.ItemRegistry.ANCIENT_WHISTLE;
import static net.codewyrm.dwdsb.registry.ItemRegistry.DISC_CORE;
import static net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper.WanderingTraderOffersBuilder.SELL_COMMON_ITEMS_POOL;
import static net.minecraft.class_1802.field_8687;

public class TradeModifier {
    public static void ModifyTrades() {
        TradeOfferHelper.registerWanderingTraderOffers(factories -> {
            factories.addOffersToPool(SELL_COMMON_ITEMS_POOL,(entity, random) -> new class_1914(
                    new class_9306(field_8687, 14),
                    new class_1799(DISC_CORE, 1),
                    1, 10, 0.075f
            ));
            factories.addOffersToPool(SELL_COMMON_ITEMS_POOL,(entity, random) -> new class_1914(
                    new class_9306(field_8687, 26),
                    new class_1799(ANCIENT_WHISTLE, 1),
                    1, 10, 0.075f
            ));
        });
    }
}



