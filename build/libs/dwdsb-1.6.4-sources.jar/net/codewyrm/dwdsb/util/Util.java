package net.codewyrm.dwdsb.util;

import java.util.Objects;
import net.minecraft.class_2960;

public class Util {

    private Util() {
    }

    public static class_2960 ofMinecraft(String name) {
        return class_2960.method_60655("minecraft", name);
    }

    public static class_2960 ofDWDSB(String name) {
        return class_2960.method_60655("dwdsb", name);
    }

    public static boolean equalsAny(Object needle, Object... haystack) {
        for (Object x : haystack) {
            if (Objects.equals(x, needle)) {
                return true;
            }
        }
        return false;
    }
}